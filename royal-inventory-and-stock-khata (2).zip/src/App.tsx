import React, { useState } from 'react';
import { 
  FileCode, 
  Folder, 
  FolderOpen, 
  Copy, 
  Check, 
  Download, 
  Search, 
  Info, 
  BookOpen, 
  Terminal, 
  ChevronRight, 
  ChevronDown, 
  Smartphone, 
  Share2, 
  Layers, 
  Database, 
  Zap 
} from 'lucide-react';

// Structuring file catalog
interface FileItem {
  name: string;
  path: string;
  type: 'kotlin' | 'xml' | 'gradle' | 'toml';
  category: 'Data / Room' | 'Dependency Injection' | 'Repository' | 'UI / Compose' | 'Config';
  content: string;
}

const FILES: FileItem[] = [
  {
    name: "StockItem.kt",
    path: "app/src/main/java/com/royal/inventory/data/StockItem.kt",
    type: "kotlin",
    category: "Data / Room",
    content: `package com.royal.inventory.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stock_items")
data class StockItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val quantity: Int,
    val cost: Double,
    val price: Double
)`
  },
  {
    name: "LedgerEntry.kt",
    path: "app/src/main/java/com/royal/inventory/data/LedgerEntry.kt",
    type: "kotlin",
    category: "Data / Room",
    content: `package com.royal.inventory.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ledger_entries")
data class LedgerEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerName: String,
    val transactionType: String, // e.g., "CREDIT", "SALE", "DEBIT"
    val amount: Double,
    val timestamp: Long = System.currentTimeMillis()
)`
  },
  {
    name: "RoyalAppDao.kt",
    path: "app/src/main/java/com/royal/inventory/data/RoyalAppDao.kt",
    type: "kotlin",
    category: "Data / Room",
    content: `package com.royal.inventory.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RoyalAppDao {
    // --- Stock Inventory Operations ---
    @Query("SELECT * FROM stock_items")
    fun getAllStockItems(): Flow<List<StockItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockItem(item: StockItem)

    @Update
    suspend fun updateStockItem(item: StockItem)

    // --- Ledger Operations ---
    @Query("SELECT * FROM ledger_entries ORDER BY timestamp DESC")
    fun getAllLedgerEntries(): Flow<List<LedgerEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntry(entry: LedgerEntry)
    
    // --- Complex Transactions ---
    @Transaction
    suspend fun processSaleTransaction(updatedItem: StockItem, entry: LedgerEntry) {
        // Ensures both updating inventory and logging the ledger entry succeed together
        updateStockItem(updatedItem)
        insertLedgerEntry(entry)
    }
}`
  },
  {
    name: "RoyalDatabase.kt",
    path: "app/src/main/java/com/royal/inventory/data/RoyalDatabase.kt",
    type: "kotlin",
    category: "Data / Room",
    content: `package com.royal.inventory.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [StockItem::class, LedgerEntry::class], 
    version = 1, 
    exportSchema = false
)
abstract class RoyalDatabase : RoomDatabase() {
    abstract fun royalAppDao(): RoyalAppDao
}`
  },
  {
    name: "AppModule.kt",
    path: "app/src/main/java/com/royal/inventory/di/AppModule.kt",
    type: "kotlin",
    category: "Dependency Injection",
    content: `package com.royal.inventory.di

import android.content.Context
import androidx.room.Room
import com.royal.inventory.data.RoyalAppDao
import com.royal.inventory.data.RoyalDatabase
import com.royal.inventory.repository.RoyalRepository
import com.royal.inventory.repository.RoyalRepositoryImpl
import com.royal.inventory.repository.SyncService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): RoyalDatabase {
        return Room.databaseBuilder(
            context,
            RoyalDatabase::class.java,
            "royal_inventory_db"
        ).build()
    }

    @Provides
    @Singleton
    fun provideRoyalAppDao(database: RoyalDatabase): RoyalAppDao {
        return database.royalAppDao()
    }
    
    @Provides
    @Singleton
    fun provideSyncService(): SyncService {
        return SyncService()
    }

    @Provides
    @Singleton
    fun provideRoyalRepository(
        dao: RoyalAppDao,
        syncService: SyncService
    ): RoyalRepository {
        return RoyalRepositoryImpl(dao, syncService)
    }
}`
  },
  {
    name: "SyncService.kt",
    path: "app/src/main/java/com/royal/inventory/repository/SyncService.kt",
    type: "kotlin",
    category: "Repository",
    content: `package com.royal.inventory.repository

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.royal.inventory.data.LedgerEntry
import com.royal.inventory.data.StockItem
import kotlinx.coroutines.tasks.await

/**
 * Firebase-backed service for syncing local Room data to Firestore.
 * Using coroutines and kotlinx-coroutines-play-services to await Tasks.
 */
class SyncService {
    
    // Lazy initialize Firestore to avoid crashes if Firebase isn't initialized yet
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    
    suspend fun syncStockItem(item: StockItem) {
        try {
            // Upsert the stock item using its ID as the document ID
            firestore.collection("stock_items")
                .document(item.id.toString())
                .set(item)
                .await()
            Log.d("SyncService", "Successfully synced stock item to cloud: \${item.name} (\${item.quantity} remaining)")
        } catch (e: Exception) {
            Log.e("SyncService", "Failed to sync stock item: \${e.message}")
            // Throwing allows the repository to handle/log the offline state correctly
            throw e
        }
    }

    suspend fun syncLedgerEntry(entry: LedgerEntry) {
        try {
            firestore.collection("ledger_entries")
                .document(entry.id.toString())
                .set(entry)
                .await()
            Log.d("SyncService", "Successfully synced ledger entry to cloud: \${entry.customerName} - \${entry.amount}")
        } catch (e: Exception) {
            Log.e("SyncService", "Failed to sync ledger entry: \${e.message}")
            throw e
        }
    }
}`
  },
  {
    name: "RoyalRepository.kt",
    path: "app/src/main/java/com/royal/inventory/repository/RoyalRepository.kt",
    type: "kotlin",
    category: "Repository",
    content: `package com.royal.inventory.repository

import com.royal.inventory.data.LedgerEntry
import com.royal.inventory.data.RoyalAppDao
import com.royal.inventory.data.StockItem
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

interface RoyalRepository {
    fun getStockItems(): Flow<List<StockItem>>
    fun getLedgerEntries(): Flow<List<LedgerEntry>>
    suspend fun processTransaction(item: StockItem, amount: Double, customer: String, isCredit: Boolean)
}

class RoyalRepositoryImpl @Inject constructor(
    private val dao: RoyalAppDao,
    private val syncService: SyncService
) : RoyalRepository {

    override fun getStockItems(): Flow<List<StockItem>> = dao.getAllStockItems()

    override fun getLedgerEntries(): Flow<List<LedgerEntry>> = dao.getAllLedgerEntries()

    override suspend fun processTransaction(
        item: StockItem, 
        amount: Double, 
        customer: String, 
        isCredit: Boolean
    ) {
        val transactionType = if (isCredit) "CREDIT" else "SALE"
        
        // Decrement stock logic (assuming 1 item per transaction for demonstration)
        // In a real app, you might pass a specific quantity to decrement.
        val quantityToDeduct = if (transactionType == "SALE") 1 else 0
        val updatedItem = item.copy(quantity = item.quantity - quantityToDeduct)
        
        val entry = LedgerEntry(
            customerName = customer,
            transactionType = transactionType,
            amount = amount
        )
        
        // Perform atomic offline save using Room transaction
        dao.processSaleTransaction(updatedItem, entry)
        
        // Background sync to Cloud (Fire-and-forget for now)
        // In a robust offline-first app, consider enqueuing this using WorkManager.
        try {
            syncService.syncStockItem(updatedItem)
            syncService.syncLedgerEntry(entry)
        } catch (e: Exception) {
            // Handle transient network errors; data is already safely stored in Room.
        }
    }
}`
  },
  {
    name: "RoyalViewModel.kt",
    path: "app/src/main/java/com/royal/inventory/ui/RoyalViewModel.kt",
    type: "kotlin",
    category: "UI / Compose",
    content: `package com.royal.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.royal.inventory.data.LedgerEntry
import com.royal.inventory.data.StockItem
import com.royal.inventory.repository.RoyalRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RoyalViewModel @Inject constructor(
    private val repository: RoyalRepository
) : ViewModel() {

    // Expose offline-first data as StateFlow for Jetpack Compose UI
    val stockItems: StateFlow<List<StockItem>> = repository.getStockItems()
        .stateIn(
            scope = viewModelScope, 
            started = SharingStarted.WhileSubscribed(5000), 
            initialValue = emptyList()
        )

    val ledgerEntries: StateFlow<List<LedgerEntry>> = repository.getLedgerEntries()
        .stateIn(
            scope = viewModelScope, 
            started = SharingStarted.WhileSubscribed(5000), 
            initialValue = emptyList()
        )

    // UI State for tracking transaction progress and errors
    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    fun processTransaction(item: StockItem, amount: Double, customer: String, isCredit: Boolean) {
        viewModelScope.launch {
            // 1. Input Validation
            if (customer.isBlank()) {
                _uiState.value = UiState.Error("Customer name cannot be blank")
                return@launch
            }
            if (amount <= 0) {
                _uiState.value = UiState.Error("Amount must be greater than 0")
                return@launch
            }
            if (!isCredit && item.quantity <= 0) {
                _uiState.value = UiState.Error("Insufficient stock for sale")
                return@launch
            }

            _uiState.value = UiState.Loading
            
            // 2. Process Data
            try {
                repository.processTransaction(item, amount, customer, isCredit)
                _uiState.value = UiState.Success("Transaction processed successfully!")
            } catch (e: Exception) {
                _uiState.value = UiState.Error("Failed to process transaction: \${e.message}")
            }
        }
    }
    
    fun consumeUiState() {
        _uiState.value = UiState.Idle
    }
}

// UI State representation
sealed class UiState {
    object Idle : UiState()
    object Loading : UiState()
    data class Success(val message: String) : UiState()
    data class Error(val message: String) : UiState()
}`
  },
  {
    name: "InventoryDashboardScreen.kt",
    path: "app/src/main/java/com/royal/inventory/ui/InventoryDashboardScreen.kt",
    type: "kotlin",
    category: "UI / Compose",
    content: `package com.royal.inventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.royal.inventory.data.StockItem
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryDashboardScreen(
    viewModel: RoyalViewModel // In production, usually injected via hiltViewModel()
) {
    // Collecting StateFlows securely using lifecycle awareness
    val stockItems by viewModel.stockItems.collectAsStateWithLifecycle()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    // Handle UI State effects (like showing errors or success messages)
    LaunchedEffect(uiState) {
        when (uiState) {
            is UiState.Error -> {
                snackbarHostState.showSnackbar((uiState as UiState.Error).message)
                viewModel.consumeUiState()
            }
            is UiState.Success -> {
                snackbarHostState.showSnackbar((uiState as UiState.Success).message)
                viewModel.consumeUiState()
            }
            else -> {}
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Royal Inventory", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = { /* TODO: Navigate to Add Item Screen */ }) {
                Icon(Icons.Filled.Add, contentDescription = "Add Item")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Dashboard Summary Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Total Items: \${stockItems.size}", style = MaterialTheme.typography.titleMedium)
                    val totalValue = stockItems.sumOf { it.quantity * it.price }
                    Text("Est. Inventory Value: \$\${totalValue}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("Current Stock", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(8.dp))

            if (stockItems.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No stock items found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(stockItems, key = { it.id }) { item ->
                        StockItemCard(
                            item = item,
                            onSellClick = {
                                // Example: Quick sell 1 unit to a walk-in customer
                                viewModel.processTransaction(
                                    item = item,
                                    amount = item.price,
                                    customer = "Walk-in Customer",
                                    isCredit = false
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StockItemCard(item: StockItem, onSellClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text("Qty: \${item.quantity}", style = MaterialTheme.typography.bodyMedium)
                    Text("Price: \$\${item.price}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                }
            }
            
            Button(
                onClick = onSellClick,
                enabled = item.quantity > 0,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Filled.ShoppingCart, contentDescription = "Sell", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sell 1")
            }
        }
    }
}`
  },
  {
    name: "RoyalApplication.kt",
    path: "app/src/main/java/com/royal/inventory/RoyalApplication.kt",
    type: "kotlin",
    category: "Dependency Injection",
    content: `package com.royal.inventory

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class RoyalApplication : Application()`
  },
  {
    name: "MainActivity.kt",
    path: "app/src/main/java/com/royal/inventory/MainActivity.kt",
    type: "kotlin",
    category: "UI / Compose",
    content: `package com.royal.inventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.royal.inventory.ui.InventoryDashboardScreen
import com.royal.inventory.ui.RoyalViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: RoyalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    InventoryDashboardScreen(viewModel = viewModel)
                }
            }
        }
    }
}`
  },
  {
    name: "AndroidManifest.xml",
    path: "app/src/main/AndroidManifest.xml",
    type: "xml",
    category: "Config",
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.royal.inventory">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <application
        android:name=".RoyalApplication"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Royal Inventory and Stock Khata"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.Material3.DayNight.NoActionBar">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.Material3.DayNight.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>`
  },
  {
    name: "app/build.gradle.kts",
    path: "app/build.gradle.kts",
    type: "gradle",
    category: "Config",
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose) // Kotlin 2.x Compose compiler plugin
    alias(libs.plugins.kotlin.kapt)
    alias(libs.plugins.hilt.android)
    alias(libs.plugins.google.services) // For Firebase Integration
}

android {
    namespace = "com.royal.inventory"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.royal.inventory"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    // --- Androidx Core & Lifecycle ---
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.activity.compose)

    // --- Jetpack Compose ---
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)

    // --- Room Database ---
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    kapt(libs.room.compiler)

    // --- Hilt Dependency Injection ---
    implementation(libs.hilt.android)
    kapt(libs.hilt.compiler)
    implementation(libs.androidx.hilt.navigation.compose)

    // --- Firebase & Firestore (Offline-ready sync) ---
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.firestore.ktx)
    implementation(libs.kotlinx.coroutines.play.services)

    // --- Testing ---
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}`
  },
  {
    name: "libs.versions.toml",
    path: "gradle/libs.versions.toml",
    type: "toml",
    category: "Config",
    content: `[versions]
agp = "8.4.0"
kotlin = "2.0.0"
coreKtx = "1.13.1"
junit = "4.13.2"
junitVersion = "1.1.5"
espressoCore = "3.5.1"
lifecycleRuntimeKtx = "2.8.1"
activityCompose = "1.9.0"
composeBom = "2024.05.00"
room = "2.6.1"
hilt = "2.51.1"
hiltNavigationCompose = "1.2.0"
firebaseBom = "33.1.0"
googleServices = "4.4.2"
coroutinesPlayServices = "1.8.1"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
junit = { group = "junit", name = "junit", version.ref = "junit" }
androidx-junit = { group = "androidx.test.ext", name = "junit", version.ref = "junitVersion" }
androidx-espresso-core = { group = "androidx.test.espresso", name = "espresso-core", version.ref = "espressoCore" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version.ref = "lifecycleRuntimeKtx" }
androidx-lifecycle-runtime-compose = { group = "androidx.lifecycle", name = "lifecycle-runtime-compose", version.ref = "lifecycleRuntimeKtx" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version.ref = "activityCompose" }
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-compose-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-compose-ui-graphics = { group = "androidx.compose.ui", name = "ui-graphics" }
androidx-compose-ui-tooling = { group = "androidx.compose.ui", name = "ui-tooling" }
androidx-compose-ui-tooling-preview = { group = "androidx.compose.ui", name = "ui-tooling-preview" }
androidx-compose-ui-test-manifest = { group = "androidx.compose.ui", name = "ui-test-manifest" }
androidx-compose-ui-test-junit4 = { group = "androidx.compose.ui", name = "ui-test-junit4" }
androidx-compose-material3 = { group = "androidx.compose.material3", name = "material3" }
androidx-compose-material-icons-extended = { group = "androidx.compose.material", name = "material-icons-extended" }

# Room Database
room-runtime = { group = "androidx.room", name = "room-runtime", version.ref = "room" }
room-ktx = { group = "androidx.room", name = "room-ktx", version.ref = "room" }
room-compiler = { group = "androidx.room", name = "room-compiler", version.ref = "room" }

# Hilt DI
hilt-android = { group = "google.dagger", name = "hilt-android", version.ref = "hilt" }
hilt-compiler = { group = "google.dagger", name = "hilt-compiler", version.ref = "hilt" }
androidx-hilt-navigation-compose = { group = "androidx.hilt", name = "hilt-navigation-compose", version.ref = "hiltNavigationCompose" }

# Firebase
firebase-bom = { group = "com.google.firebase", name = "firebase-bom", version.ref = "firebaseBom" }
firebase-firestore-ktx = { group = "com.google.firebase", name = "firebase-firestore-ktx" }
kotlinx-coroutines-play-services = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-play-services", version.ref = "coroutinesPlayServices" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
kotlin-kapt = { id = "org.jetbrains.kotlin.kapt", version.ref = "kotlin" }
hilt-android = { id = "com.google.dagger.hilt.android", version.ref = "hilt" }
google-services = { id = "com.google.gms.google-services", version.ref = "googleServices" }`
  },
  {
    name: "project/build.gradle.kts",
    path: "build.gradle.kts",
    type: "gradle",
    category: "Config",
    content: `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.kotlin.kapt) apply false
    alias(libs.plugins.hilt.android) apply false
    alias(libs.plugins.google.services) apply false
}`
  },
  {
    name: "settings.gradle.kts",
    path: "settings.gradle.kts",
    type: "gradle",
    category: "Config",
    content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "Royal Inventory and Stock Khata"
include(":app")`
  }
];

export default function App() {
  const [selectedFile, setSelectedFile] = useState<FileItem>(FILES[0]);
  const [copied, setCopied] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    'Data / Room': true,
    'Dependency Injection': true,
    'Repository': true,
    'UI / Compose': true,
    'Config': true,
  });

  const categories = ['All', 'Data / Room', 'Dependency Injection', 'Repository', 'UI / Compose', 'Config'];

  const toggleFolder = (folder: string) => {
    setExpandedFolders(prev => ({ ...prev, [folder]: !prev[folder] }));
  };

  const filteredFiles = FILES.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          file.path.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'All' || file.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Safe file exporter for offline ZIP extraction instruction
  const handleZipExportInfo = () => {
    alert("To extract the complete multi-file Android project directory automatically, go to the top-right Settings menu in Google AI Studio and click 'Export to ZIP'. This will bundle the entire working sandbox directory!");
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-neutral-100 flex flex-col font-sans selection:bg-emerald-500/30">
      
      {/* Top Banner Header */}
      <header className="border-b border-neutral-800 bg-[#0d0d11]/80 backdrop-blur-md sticky top-0 z-50 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="h-11 w-11 bg-emerald-500/10 text-emerald-400 rounded-xl flex items-center justify-center border border-emerald-500/20 shadow-md shadow-emerald-500/5">
            <Zap className="h-6 w-6 animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white tracking-tight flex items-center">
              Royal Inventory and Stock Khata
              <span className="ml-2 text-[10px] bg-emerald-500/10 text-emerald-400 font-medium px-2 py-0.5 rounded-full border border-emerald-500/20 uppercase tracking-widest">
                Android Core Dev
              </span>
            </h1>
            <p className="text-xs text-neutral-400 mt-0.5">Kotlin 2.0 • Room DB • Hilt DI • Compose • Firebase Cloud Sync</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <button 
            onClick={handleZipExportInfo}
            className="flex items-center px-4 py-2 bg-neutral-900 border border-neutral-800 text-neutral-300 text-xs font-semibold rounded-lg hover:bg-neutral-800 transition-all cursor-pointer shadow-sm"
          >
            <Download className="h-4 w-4 mr-2" />
            Download ZIP
          </button>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 flex overflow-hidden">
        
        {/* Left Sidebar: File Browser */}
        <aside className="w-80 border-r border-neutral-800 bg-[#0c0c0f] flex flex-col shrink-0">
          
          {/* Search bar */}
          <div className="p-4 border-b border-neutral-800/60">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-neutral-500" />
              <input 
                type="text" 
                placeholder="Search generated files..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-[#141419] border border-neutral-800 text-xs text-neutral-200 placeholder-neutral-500 rounded-lg pl-9 pr-4 py-2.5 outline-none focus:border-emerald-500/50 transition-colors"
              />
            </div>
          </div>

          {/* Filter Categories */}
          <div className="px-3 pt-3 pb-2 flex flex-wrap gap-1.5 border-b border-neutral-800/40">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-2.5 py-1 rounded text-[10px] font-semibold tracking-wide transition-all uppercase cursor-pointer ${
                  activeCategory === cat 
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' 
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-800/40 border border-transparent'
                }`}
              >
                {cat === 'All' ? 'All Modules' : cat}
              </button>
            ))}
          </div>

          {/* Directory Tree */}
          <div className="flex-1 overflow-y-auto p-3 space-y-4">
            
            {/* Categorized folder layout */}
            {categories.filter(c => c !== 'All').map(category => {
              const filesInCategory = filteredFiles.filter(f => f.category === category);
              if (filesInCategory.length === 0) return null;
              
              const isExpanded = expandedFolders[category] !== false;

              return (
                <div key={category} className="space-y-1">
                  <button 
                    onClick={() => toggleFolder(category)}
                    className="w-full flex items-center justify-between text-neutral-400 hover:text-white px-2 py-1.5 rounded hover:bg-neutral-800/25 transition-all text-xs font-semibold cursor-pointer"
                  >
                    <div className="flex items-center space-x-2">
                      {isExpanded ? <FolderOpen className="h-4 w-4 text-emerald-400" /> : <Folder className="h-4 w-4 text-emerald-500/60" />}
                      <span>{category}</span>
                    </div>
                    {isExpanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                  </button>

                  {isExpanded && (
                    <div className="pl-4 border-l border-neutral-800/80 ml-4 space-y-0.5 mt-1">
                      {filesInCategory.map(file => {
                        const isSelected = selectedFile.path === file.path;
                        return (
                          <button
                            key={file.path}
                            onClick={() => setSelectedFile(file)}
                            className={`w-full flex items-center space-x-2 px-2.5 py-2 rounded text-left transition-all text-xs cursor-pointer ${
                              isSelected 
                                ? 'bg-neutral-800/60 text-emerald-400 border-l-2 border-emerald-500 font-medium' 
                                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/20'
                            }`}
                          >
                            <FileCode className={`h-3.5 w-3.5 shrink-0 ${isSelected ? 'text-emerald-400' : 'text-neutral-500'}`} />
                            <span className="truncate">{file.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </aside>

        {/* Right Pane: Code Preview & Guide */}
        <section className="flex-1 flex flex-col bg-[#0b0b0e] overflow-hidden">
          
          {/* Path bar & actions */}
          <div className="px-6 py-4 border-b border-neutral-800/80 bg-[#0c0c0f]/80 flex items-center justify-between">
            <div className="flex items-center space-x-3 overflow-hidden">
              <span className="text-[10px] bg-neutral-800 text-neutral-400 px-2 py-0.5 rounded font-mono uppercase tracking-wider shrink-0">
                {selectedFile.type}
              </span>
              <span className="text-xs font-mono text-neutral-400 truncate tracking-wide">
                {selectedFile.path}
              </span>
            </div>

            <button
              onClick={handleCopy}
              className="flex items-center space-x-2 px-3.5 py-1.5 bg-emerald-500 text-black rounded-lg hover:bg-emerald-400 active:scale-95 transition-all text-xs font-bold shadow-md shadow-emerald-500/10 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>

          {/* Interactive Code Container */}
          <div className="flex-1 overflow-auto p-6 flex flex-col lg:flex-row gap-6">
            
            {/* Editor Box */}
            <div className="flex-1 bg-[#09090b] border border-neutral-800/80 rounded-xl overflow-hidden shadow-2xl flex flex-col min-h-[400px]">
              <div className="bg-[#101014] px-4 py-2.5 border-b border-neutral-800/60 flex items-center justify-between shrink-0">
                <span className="text-xs font-semibold text-neutral-300 flex items-center">
                  <Terminal className="h-4 w-4 text-emerald-400 mr-2" />
                  Source Code Editor View
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">
                  {selectedFile.content.split('\n').length} lines
                </span>
              </div>
              <pre className="flex-1 overflow-auto p-5 font-mono text-[13px] leading-relaxed text-neutral-300 selection:bg-emerald-500/20 select-text">
                <code>
                  {selectedFile.content}
                </code>
              </pre>
            </div>

            {/* Quick Integration / Architecture Specs */}
            <div className="w-full lg:w-80 shrink-0 space-y-6">
              
              {/* Feature Highlights */}
              <div className="bg-[#101014] border border-neutral-800/60 rounded-xl p-5 shadow-lg space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-300 flex items-center">
                  <Layers className="h-4 w-4 text-emerald-400 mr-2" />
                  Architecture Specs
                </h3>
                <div className="space-y-3.5 text-xs text-neutral-400">
                  <div className="flex justify-between border-b border-neutral-800 pb-2">
                    <span>Component Category:</span>
                    <span className="text-neutral-200 font-medium">{selectedFile.category}</span>
                  </div>
                  <div className="flex justify-between border-b border-neutral-800 pb-2">
                    <span>Language Syntax:</span>
                    <span className="text-neutral-200 font-medium uppercase">{selectedFile.type === 'kotlin' ? 'Kotlin 2.0' : selectedFile.type}</span>
                  </div>
                  <div className="flex justify-between border-b border-neutral-800 pb-2">
                    <span>Hilt Di Injected:</span>
                    <span className="text-emerald-400 font-medium">Yes (Singleton)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Room Offline Engine:</span>
                    <span className="text-emerald-400 font-medium">Reactive Flow</span>
                  </div>
                </div>
              </div>

              {/* Integration Steps */}
              <div className="bg-[#101014] border border-neutral-800/60 rounded-xl p-5 shadow-lg space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-300 flex items-center">
                  <BookOpen className="h-4 w-4 text-emerald-400 mr-2" />
                  Integration Guide
                </h3>
                <ol className="space-y-3.5 text-xs text-neutral-400 leading-relaxed">
                  <li className="flex items-start">
                    <span className="font-mono text-emerald-400 font-bold mr-2">1.</span>
                    <span>Create a new project in Android Studio using the <strong>Empty Compose Activity</strong> template.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="font-mono text-emerald-400 font-bold mr-2">2.</span>
                    <span>Set your project package name to <code>com.royal.inventory</code>.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="font-mono text-emerald-400 font-bold mr-2">3.</span>
                    <span>Copy-paste each file into its exact matching package directory using the Copy button.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="font-mono text-emerald-400 font-bold mr-2">4.</span>
                    <span>Configure your gradle dependencies via <code>libs.versions.toml</code> and compile!</span>
                  </li>
                </ol>
              </div>

              {/* Firebase Cloud Sync Note */}
              <div className="bg-emerald-500/5 border border-emerald-500/25 rounded-xl p-5 shadow-lg space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center">
                  <Database className="h-4 w-4 mr-2" />
                  Cloud Synchronization
                </h4>
                <p className="text-[11px] text-neutral-300 leading-relaxed">
                  The generated <code>SyncService.kt</code> integrates the official Firebase Firestore Client using suspending Kotlin extensions. Ensure your <code>google-services.json</code> is added to the <code>app/</code> directory to run.
                </p>
              </div>

            </div>
          </div>
        </section>
      </main>

      {/* Footer System Status */}
      <footer className="border-t border-neutral-800 bg-[#09090c] px-6 py-3 flex items-center justify-between text-[11px] text-neutral-500 font-mono">
        <span className="flex items-center">
          <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full mr-2 animate-ping" />
          Offline-First Sandbox Sandbox Build Success
        </span>
        <span>Environment Target: JVM 17 & Android SDK 34</span>
      </footer>

    </div>
  );
}
