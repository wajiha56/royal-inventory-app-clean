package com.royal.inventory

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class RoyalApplication : Application()
