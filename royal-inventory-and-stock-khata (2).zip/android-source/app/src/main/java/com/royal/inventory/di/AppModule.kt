package com.royal.inventory.di

import android.content.Context
import androidx.room.Room
import com.royal.inventory.data.RoyalAppDao
import com.royal.inventory.data.RoyalDatabase
import com.royal.inventory.repository.RoyalRepository
import com.royal.inventory.repository.RoyalRepositoryImpl
import com.royal.inventory.repository.SyncService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): RoyalDatabase {
        return Room.databaseBuilder(
            context,
            RoyalDatabase::class.java,
            "royal_inventory_db"
        ).build()
    }

    @Provides
    @Singleton
    fun provideRoyalAppDao(database: RoyalDatabase): RoyalAppDao {
        return database.royalAppDao()
    }
    
    @Provides
    @Singleton
    fun provideSyncService(): SyncService {
        return SyncService()
    }

    @Provides
    @Singleton
    fun provideRoyalRepository(
        dao: RoyalAppDao,
        syncService: SyncService
    ): RoyalRepository {
        return RoyalRepositoryImpl(dao, syncService)
    }
}
