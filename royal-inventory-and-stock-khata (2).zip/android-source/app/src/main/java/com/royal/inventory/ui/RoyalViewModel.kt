package com.royal.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.royal.inventory.data.LedgerEntry
import com.royal.inventory.data.StockItem
import com.royal.inventory.repository.RoyalRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RoyalViewModel @Inject constructor(
    private val repository: RoyalRepository
) : ViewModel() {

    // Expose offline-first data as StateFlow for Jetpack Compose UI
    val stockItems: StateFlow<List<StockItem>> = repository.getStockItems()
        .stateIn(
            scope = viewModelScope, 
            started = SharingStarted.WhileSubscribed(5000), 
            initialValue = emptyList()
        )

    val ledgerEntries: StateFlow<List<LedgerEntry>> = repository.getLedgerEntries()
        .stateIn(
            scope = viewModelScope, 
            started = SharingStarted.WhileSubscribed(5000), 
            initialValue = emptyList()
        )

    // UI State for tracking transaction progress and errors
    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    fun processTransaction(item: StockItem, amount: Double, customer: String, isCredit: Boolean) {
        viewModelScope.launch {
            // 1. Input Validation
            if (customer.isBlank()) {
                _uiState.value = UiState.Error("Customer name cannot be blank")
                return@launch
            }
            if (amount <= 0) {
                _uiState.value = UiState.Error("Amount must be greater than 0")
                return@launch
            }
            if (!isCredit && item.quantity <= 0) {
                _uiState.value = UiState.Error("Insufficient stock for sale")
                return@launch
            }

            _uiState.value = UiState.Loading
            
            // 2. Process Data
            try {
                repository.processTransaction(item, amount, customer, isCredit)
                _uiState.value = UiState.Success("Transaction processed successfully!")
            } catch (e: Exception) {
                _uiState.value = UiState.Error("Failed to process transaction: ${e.message}")
            }
        }
    }
    
    fun consumeUiState() {
        _uiState.value = UiState.Idle
    }
}

// UI State representation
sealed class UiState {
    object Idle : UiState()
    object Loading : UiState()
    data class Success(val message: String) : UiState()
    data class Error(val message: String) : UiState()
}
