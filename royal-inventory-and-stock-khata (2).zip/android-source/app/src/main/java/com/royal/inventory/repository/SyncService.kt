package com.royal.inventory.repository

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.royal.inventory.data.LedgerEntry
import com.royal.inventory.data.StockItem
import kotlinx.coroutines.tasks.await

/**
 * Firebase-backed service for syncing local Room data to Firestore.
 * Using coroutines and kotlinx-coroutines-play-services to await Tasks.
 */
class SyncService {
    
    // Lazy initialize Firestore to avoid crashes if Firebase isn't initialized yet
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    
    suspend fun syncStockItem(item: StockItem) {
        try {
            // Upsert the stock item using its ID as the document ID
            firestore.collection("stock_items")
                .document(item.id.toString())
                .set(item)
                .await()
            Log.d("SyncService", "Successfully synced stock item to cloud: ${item.name} (${item.quantity} remaining)")
        } catch (e: Exception) {
            Log.e("SyncService", "Failed to sync stock item: ${e.message}")
            // Throwing allows the repository to handle/log the offline state correctly
            throw e
        }
    }

    suspend fun syncLedgerEntry(entry: LedgerEntry) {
        try {
            firestore.collection("ledger_entries")
                .document(entry.id.toString())
                .set(entry)
                .await()
            Log.d("SyncService", "Successfully synced ledger entry to cloud: ${entry.customerName} - ${entry.amount}")
        } catch (e: Exception) {
            Log.e("SyncService", "Failed to sync ledger entry: ${e.message}")
            throw e
        }
    }
}
