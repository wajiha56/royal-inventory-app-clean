package com.royal.inventory.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ledger_entries")
data class LedgerEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerName: String,
    val transactionType: String, // e.g., "CREDIT", "SALE", "DEBIT"
    val amount: Double,
    val timestamp: Long = System.currentTimeMillis()
)
