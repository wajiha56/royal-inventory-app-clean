package com.royal.inventory.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RoyalAppDao {
    // --- Stock Inventory Operations ---
    @Query("SELECT * FROM stock_items")
    fun getAllStockItems(): Flow<List<StockItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockItem(item: StockItem)

    @Update
    suspend fun updateStockItem(item: StockItem)

    // --- Ledger Operations ---
    @Query("SELECT * FROM ledger_entries ORDER BY timestamp DESC")
    fun getAllLedgerEntries(): Flow<List<LedgerEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntry(entry: LedgerEntry)
    
    // --- Complex Transactions ---
    @Transaction
    suspend fun processSaleTransaction(updatedItem: StockItem, entry: LedgerEntry) {
        // Ensures both updating inventory and logging the ledger entry succeed together
        updateStockItem(updatedItem)
        insertLedgerEntry(entry)
    }
}
