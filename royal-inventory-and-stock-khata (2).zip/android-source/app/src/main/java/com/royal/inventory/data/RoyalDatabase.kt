package com.royal.inventory.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [StockItem::class, LedgerEntry::class], 
    version = 1, 
    exportSchema = false
)
abstract class RoyalDatabase : RoomDatabase() {
    abstract fun royalAppDao(): RoyalAppDao
}
