package com.royal.inventory.repository

import com.royal.inventory.data.LedgerEntry
import com.royal.inventory.data.RoyalAppDao
import com.royal.inventory.data.StockItem
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

interface RoyalRepository {
    fun getStockItems(): Flow<List<StockItem>>
    fun getLedgerEntries(): Flow<List<LedgerEntry>>
    suspend fun processTransaction(item: StockItem, amount: Double, customer: String, isCredit: Boolean)
}

class RoyalRepositoryImpl @Inject constructor(
    private val dao: RoyalAppDao,
    private val syncService: SyncService
) : RoyalRepository {

    override fun getStockItems(): Flow<List<StockItem>> = dao.getAllStockItems()

    override fun getLedgerEntries(): Flow<List<LedgerEntry>> = dao.getAllLedgerEntries()

    override suspend fun processTransaction(
        item: StockItem, 
        amount: Double, 
        customer: String, 
        isCredit: Boolean
    ) {
        val transactionType = if (isCredit) "CREDIT" else "SALE"
        
        // Decrement stock logic (assuming 1 item per transaction for demonstration)
        // In a real app, you might pass a specific quantity to decrement.
        val quantityToDeduct = if (transactionType == "SALE") 1 else 0
        val updatedItem = item.copy(quantity = item.quantity - quantityToDeduct)
        
        val entry = LedgerEntry(
            customerName = customer,
            transactionType = transactionType,
            amount = amount
        )
        
        // Perform atomic offline save using Room transaction
        dao.processSaleTransaction(updatedItem, entry)
        
        // Background sync to Cloud (Fire-and-forget for now)
        // In a robust offline-first app, consider enqueuing this using WorkManager.
        try {
            syncService.syncStockItem(updatedItem)
            syncService.syncLedgerEntry(entry)
        } catch (e: Exception) {
            // Handle transient network errors; data is already safely stored in Room.
        }
    }
}
